"""Conservatively extract whole-facility bed counts from the FDR description field."""

from argparse import ArgumentParser
from collections import Counter
import json
from pathlib import Path
import re
from urllib.parse import urlsplit

import numpy as np
import pandas as pd

from facility_tool.workspace import Store
from xgboost_capacity import _eligible_rows


NUMBER = r"(?:\d{1,3}(?:,\d{2,3})+|\d+)"
MENTION = re.compile(
    rf"(?<![\w.,])(?P<leading>{NUMBER})\s*[-–—]?\s*(?:(?:inpatient|hospital)\s+)?bed(?:s|ded)?\b"
    rf"|\b(?:beds?\s*(?:capacity|count|strength)?|capacity)\s*(?:(?:is|of)\s+)?[:=]?\s*(?P<trailing>{NUMBER})(?!\w|[.,]\d)",
    re.I,
)
SENTENCE_BOUNDARY = re.compile(r"(?<=[.!?;])\s+|\r?\n")
APPROXIMATED = re.compile(
    r"(?:more than|less than|greater than|just under|just over|over|under|over a total of|"
    r"at least|at most|up to|around|about|approx(?:imately)?\.?|nearly|at capacity of)\s*$|"
    r"\d\s*(?:[-–—]|to|or)\s*$|[+<>~≤≥]\s*$|\bbetween\b[^.;]{0,25}$", re.I,
)
HISTORICAL_OR_PLANNED = re.compile(
    r"\b(?:began|started (?:out|with|as)|originally|former(?:ly)?|previously|once had|initially|"
    r"first opened|was (?:established|founded|opened) (?:as|with)|formerly|"
    r"grew from|increased from|expanded from|rose from|used to|discontinued|"
    r"will\s+(?:be|add|have|offer|house|provide)|plans? to|expected to|projected|"
    r"planned (?:capacity|bed)|proposed|under construction|being built|temporary|field hospital)\b", re.I,
)
DISCONTINUED_INPATIENT = re.compile(
    r"\b(?:indoor|inpatient|hospitalization|overnight)\b[^.!?;]{0,70}\b(?:discontinued|closed|ceased|stopped)\b", re.I,
)
AGGREGATE = re.compile(
    r"\b(?:across\s+(?:all|its|the|\d)|\d+\s+(?:hospitals|branches|locations)|"
    r"network|group\s+of\s+hospitals|chains?\s+of\s+hospitals|combined|aggregate|between\s+\w+\s+and)\b", re.I,
)
SUBUNIT = re.compile(
    r"\b(?:icu|nicu|picu|sicu|ccu|itu|intensive care|critical care|emergency|trauma|dialysis|"
    r"neonatal|paediatric|pediatric|onco\w*|obstetrics|gynecology|maternity|cardiac|burn|"
    r"hdu|day care|ward|room|floor|unit|department|wing|isolation)\b", re.I,
)
EXTERNAL = re.compile(
    r"\b(?:associated hospital|nearby hospital|adjacent hospital|referral hospital has|"
    r"affiliated hospital|parent hospital|at another facility|at hotel|tie[- ]?up|"
    r"beds?\s+(?:at|of)\s+(?!the\s+(?:site|facility|hospital)\b)[A-Za-z][\w'-]*)\b", re.I,
)
WHOLE_DESCRIPTOR = re.compile(
    r"^\s+(?:(?:multi[- ]?special(?:ity|ty)|super[- ]?special(?:ity|ty)|regional|referral|tertiary|"
    r"secondary|charitable|multidisciplinary|special(?:ity|ty)|general|modern|private|government|"
    r"teaching|speciali[sz]ed|paediatric|pediatric|children's|heart|eye|comprehensive|rural|district|"
    r"portable|multilevel|state-of-the-art)\s+){0,6}"
    r"(?:hospital|nursing home|medical cent(?:re|er)|regional referral cent(?:re|er)|facility)\b", re.I,
)
WHOLE_SUBJECT = re.compile(
    r"\b(?:hospital|facility|nursing home|medical cent(?:re|er)|it|we)\s+"
    r"(?:now\s+|currently\s+)?(?:has|have|houses|accommodates|maintains|has a capacity of|"
    r"includes|boasts|comprises|consists of|provides|provided|offers|features|has been equipped with|"
    r"have also provided|is equipped with)\s+(?:a total of\s+|a capacity of\s+)?$"
    r"|\b(?:now\s+boasting|bed capacity\s+(?:of|is)|a\s+total\s+of)\s*$", re.I,
)
WHOLE_FROM_RIGHT = re.compile(r"^[\s,]+(?:the\s+)?(?:hospital|facility|nursing home)\s+(?:is|offers|has|provides)\b", re.I)
UNIT_AFTER = re.compile(
    r"^[\s-]+(?:(?:for\s+the|surgical|medical|paediatric|pediatric|neonatal|level\s+\w+)\s+){0,2}"
    r"(?:icu|nicu|picu|sicu|ccu|intensive care|critical care|trauma|dialysis|wards?|rooms?|units?)\b", re.I,
)
WHOLE_CAPACITY = re.compile(r"\b(?:total\s+(?:of\s+)?beds?|bed\s+(?:capacity|count|strength)|total\s+(?:inpatient\s+)?capacity)\b", re.I)
OLD_DATE = re.compile(r"\b(?:in|by|until|as of)\s+(?:18|19)\d{2}\b", re.I)
PAST_ONLY = re.compile(r"\b(?:it|hospital|facility)\s+(?:had|was)\b(?:(?!\b(?:now|currently|has|houses)\b).)*$", re.I)
RANGE_AFTER = re.compile(r"^\s*(?:[+<>~≤≥]|(?:[-–—]|to|or)\s*\d)", re.I)
URL = re.compile(r"^https?://[^\s]+$", re.I)
NULL_WORDS = {"", "null", "nan", "none", "not available", "not stated", "unknown", "n/a", "na"}


def text(value):
    return str(value).strip() if pd.api.types.is_scalar(value) and not pd.isna(value) else ""


def source_link(record):
    try:
        urls = json.loads(text(record["source_urls"]))
    except (TypeError, ValueError):
        urls = []
    source_urls = [url for url in urls if isinstance(url, str) and URL.fullmatch(url)] if isinstance(urls, list) else []
    official = text(record["officialWebsite"])
    if URL.fullmatch(official):
        def host(url):
            return urlsplit(url).netloc.lower().removeprefix("www.")

        for url in source_urls:
            if host(url) == host(official):
                return url
    return next(iter(source_urls), official if URL.fullmatch(official) else None)


def extract_description(description):
    """Return validated candidate excerpts and counts noticed with uncertain scope."""
    verified = []
    saw_count = False
    if DISCONTINUED_INPATIENT.search(description):
        return verified, bool(MENTION.search(description))
    for sentence in SENTENCE_BOUNDARY.split(description):
        for hit in MENTION.finditer(sentence):
            saw_count = True
            left = sentence[:hit.start()]
            right = sentence[hit.end():]
            clause_left = re.split(r"[,;:]|\s+and\s+", left)[-1]
            clause_right = re.split(r"[,;:]|\s+and\s+", right)[0]
            count = int((hit["leading"] or hit["trailing"]).replace(",", ""))
            if (not 1 <= count <= 10000 or APPROXIMATED.search(left) or RANGE_AFTER.search(right)
                    or HISTORICAL_OR_PLANNED.search(sentence) or AGGREGATE.search(sentence)
                    or EXTERNAL.search(sentence) or OLD_DATE.search(clause_left + hit[0] + clause_right)
                    or PAST_ONLY.search(left) or UNIT_AFTER.search(right)):
                continue

            bounded_total = bool(WHOLE_DESCRIPTOR.match(right))
            explicit_total = bool(WHOLE_CAPACITY.search(hit[0]) or WHOLE_SUBJECT.search(left)
                                  or WHOLE_FROM_RIGHT.match(right))
            # A facility descriptor or direct subject supplies scope. Unit descriptions and external
            # references near an otherwise terse bed count cannot stand in for a branch-wide total.
            if explicit_total and SUBUNIT.search(clause_left[max(0, len(clause_left) - 65):]):
                explicit_total = False
            if bounded_total or explicit_total:
                evidence = sentence.strip()
                if len(evidence) > 420:
                    evidence = sentence[max(0, hit.start() - 120): min(len(sentence), hit.end() + 150)].strip()
                verified.append((count, evidence))
    return verified, saw_count


def load_snapshot(root, base, as_of):
    audits = Store(root, "export", as_of, base / "full_audit")
    locations = Store(root, "export", as_of, base / "location-audit-6y22xg3u")
    raw = locations.read("linked_fdr")
    rows, audit, _ = _eligible_rows(
        raw, audits.read("capacity_target_audit"), audits.read("number_doctors_target_audit"),
        locations.read("location_records"), locations.read("location_entity_review"),
    )
    return raw.loc[raw["facility_id"].isin(rows.index)], rows, audit


def run(root, base, as_of):
    raw, rows, audit = load_snapshot(root, base, as_of)
    statuses = {"reported": Counter(), "missing": Counter()}
    total = Counter()
    by_split = {split: Counter() for split in ("train", "calibration", "test")}
    records = []
    for facility_id, frame in raw.groupby("facility_id", sort=True):
        canonical = rows.loc[facility_id]
        label = audit.loc[facility_id]
        candidates = {}
        saw_count = False
        for _, source in frame.sort_values("unique_id", kind="stable").iterrows():
            description = text(source["description"])
            if description.casefold() in NULL_WORDS:
                continue
            fits, mentions_count = extract_description(description)
            saw_count |= mentions_count
            for count, evidence in fits:
                if count not in candidates:
                    candidates[count] = (evidence, text(source["unique_id"]), source_link(source))

        observed = int(label["value"]) if label["status"] == "reported" else None
        if len(candidates) == 1:
            status = "extracted"
            value, (evidence, source_id, source_url) = next(iter(candidates.items()))
        else:
            status = "conflicting_counts" if candidates else "unclear_scope" if saw_count else "no_explicit_count"
            value = evidence = source_id = source_url = None

        records.append({
            "facility_id": facility_id, "facility_name": text(canonical["name"]),
            "city": text(canonical["address_city"]), "state": text(canonical["address_stateOrRegion"]),
            "reported_capacity": observed, "description_capacity": value, "split": label["split"],
            "extraction_status": status, "evidence": evidence, "source_id": source_id, "source_url": source_url,
        })
        total[status] += 1
        statuses[label["status"]][status] += 1
        by_split[label["split"]]["reported" if observed is not None else "missing"] += 1
        if value is not None:
            by_split[label["split"]]["extracted_reported" if observed is not None else "extracted_missing"] += 1
            if observed is not None:
                by_split[label["split"]]["exact_reported" if observed == value else "different_reported"] += 1

    paired = [r for r in records if r["reported_capacity"] is not None and r["description_capacity"] is not None]
    exact = sum(r["reported_capacity"] == r["description_capacity"] for r in paired)
    summary = {
        "eligible_facilities": len(records),
        "reported_capacity": sum(statuses["reported"].values()),
        "missing_capacity": sum(statuses["missing"].values()),
        "extracted_reported": statuses["reported"]["extracted"],
        "extracted_missing": statuses["missing"]["extracted"],
        "paired_exact": exact,
        "paired_different": len(paired) - exact,
        "paired_exact_share": exact / len(paired) if paired else None,
        "paired_mae": float(np.mean([abs(r["reported_capacity"] - r["description_capacity"]) for r in paired])) if paired else None,
        "status_counts": dict(total), "status_counts_by_original_capacity": {k: dict(v) for k, v in statuses.items()},
        "by_split": {k: dict(v) for k, v in by_split.items()},
    }
    return {"records": records, "summary": summary}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--as-of", default="2026-11-21")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = run(args.root, args.snapshot, args.as_of)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(result["summary"], indent=2))
