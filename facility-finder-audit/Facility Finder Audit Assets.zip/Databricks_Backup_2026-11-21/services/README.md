# Workspace services

The Databricks CLI did not list any user-created jobs, pipelines, saved SQL queries, dashboards, alerts, Apps, serving endpoints, compute clusters, compute policies, instance pools, init scripts, custom base environments, AI Search endpoints, Lakebase instances or projects, or Agent Bricks agents. No workspace secret scopes or personal Genie Agent conversations were listed. See `inventory.json` for the complete checks and the names of the built-in objects.

The project has no service definitions to restore from this directory. The default workspace settings and the full starter Genie definition are retained as reference:

- `bakehouse_genie_space.json` contains the serialized starter Genie space with sample data dependencies. To recreate it in another workspace, use a SQL warehouse there, ensure the listed sample tables are available, encode the `serialized_space` object as a JSON string, and pass it to the Genie create-space API with the title and destination warehouse ID.
- `starter_warehouse_settings.json` records the original starter warehouse settings. A new workspace uses a different warehouse ID.
- `workspace_base_environments.json` identifies the Databricks-provided base environments and the default GPU base environment.

The foundation-model serving endpoints listed in the inventory were Databricks system endpoints. User-trained candidate models, experiments and artifacts are covered in the `models/` backup. Proprietary credentials, personal access tokens and secret values are excluded. Genie Code chat history is distinct from Genie Agent conversations; no supported offline export of Genie Code chat history was identified.

References: [Genie API](https://docs.databricks.com/api/genie/v1/genie-list-spaces), [Databricks Foundation Model APIs](https://docs.databricks.com/aws/en/machine-learning/foundation-model-apis), [Genie Code chat history](https://docs.databricks.com/aws/en/genie-code/navigate-genie-code).
