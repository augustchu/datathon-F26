# Databricks workspace backup

Captured November 21, 2026 from workspace `7474653522248845`. This local folder supplements `augustchu/datathon-F26` on GitHub at commit `91684123f7c0301310f13ba64316167b252d5fb3`.

| What was checked | Result |
| --- | --- |
| Project files and notebooks | 383 compared with GitHub. 381 matched. The two notebook exports below preserve workspace settings that differ from GitHub. Their cell sources match GitHub. |
| Tables and volumes | No user-created tables or volumes were visible. A direct lookup confirmed `workspace.default.facilities_enriched` does not exist. The three Databricks Marketplace inputs are documented with their schemas in `tables/`. |
| Saved models | No accessible logged model artifacts or user-registered models were found. The `models/` folder contains the inventory. |
| Other workspace services | No project-created jobs, dashboards, queries, serving endpoints, or other services were found. `services/` records the checks and default configuration for reference. |

`workspace/objects/` contains Jupyter copies of `capacity_random_forest` and `Enriched Capacity GPU Training`, organized by their original paths. `workspace/dbc/` contains the corresponding Databricks archives. The original workspace paths, GitHub paths, checksums, and inventory are in `workspace/manifest.json`. The GPU probe, GPU diagnostic run files, and Genie Code conversations were excluded at your request. Internal Git and credential-bearing configuration are outside the backup.

To restore the project, clone the GitHub repository at the commit above and import the two Jupyter copies into the matching paths in the new workspace if you need their Databricks settings. The DBC files are alternate import formats. Workspace-specific compute options may need to be selected again. The exports capture the saved notebooks, including outputs exposed by the export API. They do not capture live sessions, unsaved changes, or version history. See [Databricks import and export](https://docs.databricks.com/aws/en/notebooks/notebook-export-import).

To rebuild the enriched table, regain access to the Marketplace share described in `tables/README.md`, set a writable destination in the NFHS-5 enrichment notebook, and run it. Then run the training notebook on the intended compute to recreate a model. No training was run for this backup.

To verify the local copy on macOS, run `shasum -a 256 -c SHA256SUMS` from this folder.
