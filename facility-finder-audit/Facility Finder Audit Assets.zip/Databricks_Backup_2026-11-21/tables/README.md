# Databricks data inventory

This inventory records what was visible in workspace `7474653522248845` on November 21, 2026. It was collected through the Databricks CLI with the `datathon` profile. The inventory did not start a SQL warehouse or change the workspace.

The local Unity Catalog catalog, `workspace`, contains one non-system schema, `default`. The normal and browse-inclusive listings each returned zero tables. The volumes and functions listings also returned zero assets. A direct lookup of `workspace.default.facilities_enriched` returned “does not exist.” The workspace has legacy access disabled and does not expose a `hive_metastore` catalog. Its DBFS root lists only the built-in `Volumes`, `Workspace`, and `databricks-datasets` paths. There were no workspace tables or volumes to export as data files.

The read-only Marketplace catalog `databricks_virtue_foundation_dataset_dais_2026` is a Delta Sharing subscription to provider `databricks` and share `virtuefoundationdataset`. This backup records the sharing catalog, table names, and column definitions for `facilities`, `india_post_pincode_directory`, and `nfhs_5_district_health_indicators`. To access the source rows in a new workspace, subscribe to the listing again or request access from the Datathon organizers. `system` and `samples` are provider catalogs.

After restoring the source access and choosing a writable catalog and schema, the [NFHS-5 Socioeconomic Enrichment notebook](https://github.com/augustchu/datathon-F26/blob/main/notebooks/NFHS-5%20Socioeconomic%20Enrichment.ipynb) can recreate the enriched table at its configured destination. The independently stored notebook copies elsewhere in this backup may include changes made after GitHub commit `9168412`.
